class Model2H(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  lstm : __torch__.torch.nn.modules.rnn.___torch_mangle_21.LSTM
  fc1 : __torch__.torch.nn.modules.linear.___torch_mangle_22.Linear
  relu1 : __torch__.torch.nn.modules.activation.___torch_mangle_23.ReLU
  fc : __torch__.torch.nn.modules.linear.___torch_mangle_24.Linear
  def forward(self: __torch__.fil_lstm.model_2h.___torch_mangle_25.Model2H,
    x: Tensor,
    prev_h: Tensor,
    prev_c: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    fc = self.fc
    relu1 = self.relu1
    fc1 = self.fc1
    lstm = self.lstm
    _0, _1, = (lstm).forward(x, prev_h, prev_c, )
    _2 = torch.slice(torch.select(_0, 0, -1), 0, 0, 9223372036854775807)
    input = torch.slice(_2, 1, 0, 9223372036854775807)
    _3 = (relu1).forward((fc1).forward(input, ), )
    return ((fc).forward(_3, ), _0, _1)
