class Model2HReceive(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  lstm : __torch__.torch.nn.modules.rnn.LSTM
  fc1 : __torch__.torch.nn.modules.linear.Linear
  relu1 : __torch__.torch.nn.modules.activation.ReLU
  fc2 : __torch__.torch.nn.modules.linear.___torch_mangle_0.Linear
  relu2 : __torch__.torch.nn.modules.activation.___torch_mangle_1.ReLU
  fc : __torch__.torch.nn.modules.linear.___torch_mangle_2.Linear
  def forward(self: __torch__.fil_lstm.model_2h_rec.Model2HReceive,
    x: Tensor,
    prev_h: Tensor,
    prev_c: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    fc = self.fc
    relu2 = self.relu2
    fc2 = self.fc2
    relu1 = self.relu1
    fc1 = self.fc1
    lstm = self.lstm
    _0, _1, = (lstm).forward(x, prev_h, prev_c, )
    _2 = torch.slice(torch.select(_0, 0, -1), 0, 0, 9223372036854775807)
    input = torch.slice(_2, 1, 0, 9223372036854775807)
    _3 = (relu1).forward((fc1).forward(input, ), )
    _4 = (relu2).forward((fc2).forward(_3, ), )
    return ((fc).forward(_4, ), _0, _1)
