class LSTM(Module):
  __parameters__ = ["weight_ih_l0", "weight_hh_l0", "bias_ih_l0", "bias_hh_l0", ]
  __buffers__ = []
  weight_ih_l0 : Tensor
  weight_hh_l0 : Tensor
  bias_ih_l0 : Tensor
  bias_hh_l0 : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.rnn.___torch_mangle_2.LSTM,
    input: Tensor,
    hx: Tensor,
    hx0: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    _0 = self.bias_hh_l0
    _1 = self.bias_ih_l0
    _2 = self.weight_hh_l0
    _3 = self.weight_ih_l0
    input0, _4, _5 = torch.lstm(input, [hx, hx0], [_3, _2, _1, _0], True, 1, 0.5, True, False, False)
    return (input0, _4, _5)
