class Model(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  lstm : __torch__.torch.nn.modules.rnn.___torch_mangle_2.LSTM
  fc1 : __torch__.torch.nn.modules.linear.___torch_mangle_3.Linear
  relu1 : __torch__.torch.nn.modules.activation.___torch_mangle_4.ReLU
  fc : __torch__.torch.nn.modules.linear.___torch_mangle_5.Linear
  relu : __torch__.torch.nn.modules.activation.___torch_mangle_6.ReLU
  def forward(self: __torch__.fil_lstm.model.___torch_mangle_7.Model,
    input: Tensor,
    hx: Tensor,
    hx0: Tensor) -> Tuple[Tensor, Tuple[Tensor, Tensor]]:
    _0 = self.relu
    _1 = self.fc
    _2 = self.relu1
    _3 = self.fc1
    _4 = (self.lstm).forward(input, hx, hx0, )
    _5, _6, _7, = _4
    _8 = (_1).forward((_2).forward((_3).forward(_5, ), ), )
    _9 = torch.slice((_0).forward(_8, ), 0, 0, 9223372036854775807, 1)
    _10 = torch.slice(torch.select(_9, 1, -1), 1, 0, 9223372036854775807, 1)
    return (_10, (_6, _7))
