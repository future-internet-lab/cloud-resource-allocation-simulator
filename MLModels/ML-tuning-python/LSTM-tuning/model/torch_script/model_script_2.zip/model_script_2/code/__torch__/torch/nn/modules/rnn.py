class LSTM(Module):
  __parameters__ = ["weight_ih_l0", "weight_hh_l0", "bias_ih_l0", "bias_hh_l0", ]
  __buffers__ = []
  weight_ih_l0 : Tensor
  weight_hh_l0 : Tensor
  bias_ih_l0 : Tensor
  bias_hh_l0 : Tensor
  training : bool
  _is_full_backward_hook : Optional[bool]
  def forward(self: __torch__.torch.nn.modules.rnn.LSTM,
    x: Tensor,
    hx: Tensor,
    hx0: Tensor) -> Tuple[Tensor, Tensor, Tensor]:
    bias_hh_l0 = self.bias_hh_l0
    bias_ih_l0 = self.bias_ih_l0
    weight_hh_l0 = self.weight_hh_l0
    weight_ih_l0 = self.weight_ih_l0
    _0 = [hx, hx0]
    _1 = [weight_ih_l0, weight_hh_l0, bias_ih_l0, bias_hh_l0]
    input, _2, _3 = torch.lstm(x, _0, _1, True, 1, 0.5, True, False, False)
    return (input, _2, _3)
