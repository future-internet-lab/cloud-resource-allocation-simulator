class Model(Module):
  __parameters__ = []
  __buffers__ = []
  training : bool
  _is_full_backward_hook : Optional[bool]
  lstm : __torch__.torch.nn.modules.rnn.LSTM
  fc1 : __torch__.torch.nn.modules.linear.Linear
  relu1 : __torch__.torch.nn.modules.activation.ReLU
  fc : __torch__.torch.nn.modules.linear.___torch_mangle_0.Linear
  relu : __torch__.torch.nn.modules.activation.___torch_mangle_1.ReLU
  def forward(self: __torch__.fil_lstm.model.Model,
    x: Tensor,
    prev_state: Tuple[Tensor, Tensor]) -> Tuple[Tensor, Tuple[Tensor, Tensor]]:
    relu = self.relu
    fc = self.fc
    relu1 = self.relu1
    fc1 = self.fc1
    lstm = self.lstm
    hx, hx0, = prev_state
    _0, _1, _2, = (lstm).forward(x, hx, hx0, )
    _3 = (relu1).forward((fc1).forward(_0, ), )
    _4 = (relu).forward((fc).forward(_3, ), )
    _5 = torch.slice(_4, 0, 0, 9223372036854775807)
    _6 = torch.slice(torch.select(_5, 1, -1), 1, 0, 9223372036854775807)
    return (_6, (_1, _2))
