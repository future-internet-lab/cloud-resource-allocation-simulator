- 24h-n.xlsx with n means the length of time window that is used to capture the features 
- For each Excel file, please create 2 ML models for 2 objects: Density and Receive ==> In total: 6 ML model
- Officially, every file represents 178 days, but 24h-2 has 182 days with 4 days extra due to error in recording data.
  Thus, removing 4 days randomly or still include it in the ML training is up to you.